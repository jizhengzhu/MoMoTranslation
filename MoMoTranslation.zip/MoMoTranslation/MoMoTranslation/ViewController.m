//
//  ViewController.m
//  MoMoTranslation
//
//  Created by Jim on 2016/12/20.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import <Speech/Speech.h>
//#import <AVFoundation/AVFoundation.h>
#define screenW [UIScreen mainScreen].bounds.size.width
#define screenH [UIScreen mainScreen].bounds.size.height
#define youdaoURL @"https://fanyi.youdao.com/openapi.do"
#define youdaoAppKey @"11754227"
@interface ViewController () <SFSpeechRecognitionTaskDelegate>

@property (nonatomic, strong) UIButton *startbtn;
@property (nonatomic, strong) UIButton *stopbtn;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UILabel *translationLabel;
@property (nonatomic, strong) UILabel *errorLabel;
@property (nonatomic, strong) NSString *pathRecord;
@property (nonatomic, strong) AVAudioRecorder *recorder;

@end


@implementation ViewController

- (UILabel *)label
{
    if (!_label) {
        
        _label = [[UILabel alloc] initWithFrame:CGRectMake((screenW - 200) / 2, (screenH - 35) / 2 - 120, 200, 35)];

        _label.layer.cornerRadius = 6;
        _label.layer.masksToBounds = YES;
        _label.backgroundColor = [UIColor colorWithRed:1 green:0.5 blue:0 alpha:0.5];
    }
    return _label;
}

- (UILabel *)translationLabel
{
    if (!_translationLabel) {
        
        _translationLabel = [[UILabel alloc] initWithFrame:CGRectMake((screenW - 200) / 2, (screenH - 35) / 2 - 60, 200, 35)];
        _translationLabel.layer.cornerRadius = 6;
        _translationLabel.layer.masksToBounds = YES;
        _translationLabel.backgroundColor = [UIColor colorWithRed:1 green:0.5 blue:0 alpha:0.5];
    }
    return _translationLabel;
}

- (UIButton *)startbtn
{
    if (!_startbtn) {
        
        _startbtn = [[UIButton alloc] initWithFrame:CGRectMake((screenW - 200) / 2, (screenH - 35) / 2, 200, 35)];
        [_startbtn addTarget:self action:@selector(startRecord) forControlEvents:UIControlEventTouchUpInside];
        [_startbtn setTitle:@"start" forState:UIControlStateNormal];
        _startbtn.layer.shadowOffset = CGSizeMake(2, 2);
        _startbtn.layer.shadowColor = [UIColor grayColor].CGColor;
        _startbtn.layer.shadowOpacity = 0.8;
        _startbtn.backgroundColor = [UIColor greenColor];
    }
    return _startbtn;
}

- (UIButton *)stopbtn
{
    if (!_stopbtn) {
        
        _stopbtn = [[UIButton alloc] initWithFrame:CGRectMake((screenW - 200) / 2, (screenH - 35) / 2 + 60, 200, 35)];
        [_stopbtn addTarget:self action:@selector(stopRecord) forControlEvents:UIControlEventTouchUpInside];
        [_stopbtn setTitle:@"stop" forState:UIControlStateNormal];
        _stopbtn.layer.shadowOffset = CGSizeMake(2, 2);
        _stopbtn.layer.shadowColor = [UIColor grayColor].CGColor;
        _stopbtn.layer.shadowOpacity = 0.8;
        _stopbtn.backgroundColor = [UIColor greenColor];
    }
    return _stopbtn;
}

- (UILabel *)errorLabel
{
    if (!_errorLabel) {
        
        _errorLabel = [[UILabel alloc] initWithFrame:CGRectMake((screenW - 200) / 2, (screenH - 35) / 2 + 120, 200, 35)];
        _errorLabel.layer.cornerRadius = 6;
        _errorLabel.layer.masksToBounds = YES;
        _errorLabel.backgroundColor = [UIColor colorWithWhite:0.5 alpha:0.5];
        _errorLabel.text = @"error:";
    }
    return _errorLabel;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setupAudioRecorder];
    [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status) {
        NSLog(@"status = %ld", (long)status);
    }];
    self.label.text = @"";
    self.translationLabel.text = @"";
    self.errorLabel.text = @"error:";
    [self.view addSubview:self.label];
    [self.view addSubview:self.translationLabel];
    [self.view addSubview:self.errorLabel];
    [self.view addSubview:self.stopbtn];
    [self.view addSubview:self.startbtn];
}

- (void)setupAudioRecorder{
    // 设置录音路径
    self.pathRecord = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject stringByAppendingPathComponent:@"record.caf"];
    // 如果这段代码不添加真机运行会出现问题
    AVAudioSession *session = [AVAudioSession sharedInstance];
    NSError *setCategoryError = nil;
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&setCategoryError];
    // 实例化录音对象
    NSError *errorRecord = nil;
    self.recorder = [[AVAudioRecorder alloc]initWithURL:[NSURL fileURLWithPath:self.pathRecord] settings:@{AVNumberOfChannelsKey:@2,AVSampleRateKey:@44100,AVLinearPCMBitDepthKey:@32,AVEncoderAudioQualityKey:@(AVAudioQualityMax),AVEncoderBitRateKey:@128000} error:&errorRecord];
    // 准备录音
    [self.recorder prepareToRecord];
}

- (void)startRecord
{
    NSLog(@"%s", __FUNCTION__);
    self.label.text = @"";
    self.translationLabel.text = @"";
    self.errorLabel.text = @"error:";
    self.startbtn.backgroundColor = [UIColor redColor];
    [self.recorder record];
}

- (void)stopRecord
{
    self.startbtn.backgroundColor = [UIColor greenColor];
    NSLog(@"%s", __FUNCTION__);

    [self.recorder stop];
    [self identificationSoundRecording];
}

// 识别录音
- (void)identificationSoundRecording {
    //请求权限
    [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status) {
        /*
         status 为请求权限的结果，有以下几个状态：
         1 用户没有选择
         SFSpeechRecognizerAuthorizationStatusNotDetermined,
         2 用户拒绝了语音识别请求
         SFSpeechRecognizerAuthorizationStatusDenied,
         3 使用的设备不支持语音识别
         SFSpeechRecognizerAuthorizationStatusRestricted,
         4 取得了用户的授权
         SFSpeechRecognizerAuthorizationStatusAuthorized,
         */
        // 获取权限成功
        if (status == SFSpeechRecognizerAuthorizationStatusAuthorized) {
            NSURL *url = [NSURL fileURLWithPath:self.pathRecord];
            // 实例化语音识别对象
            SFSpeechRecognizer *recongize = [[SFSpeechRecognizer alloc] init];
            SFSpeechURLRecognitionRequest *request = [[SFSpeechURLRecognitionRequest alloc] initWithURL:url];
            // 根据请求进行语音识别
            [recongize recognitionTaskWithRequest:request delegate:self];
        }
    }];
}

#pragma mark SFSpeechRecognitionTaskDelegate Methods
- (void)speechRecognitionDidDetectSpeech:(SFSpeechRecognitionTask *)task{
    NSLog(@"%s", __FUNCTION__);
}

- (void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didHypothesizeTranscription:(SFTranscription *)transcription
{
    NSLog(@"%s", __FUNCTION__);
    self.label.text = transcription.formattedString;

}

- (void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didFinishRecognition:(SFSpeechRecognitionResult *)recognitionResult
{
    NSLog(@"%s", __FUNCTION__);
    NSString *result = recognitionResult.bestTranscription.formattedString;
    NSLog(@"result = %@", result);
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"keyfrom"] = @"MoMoTranslation";
    param[@"key"] = youdaoAppKey;
    param[@"type"] = @"data";
    param[@"doctype"] = @"json";
    param[@"version"] = @"1.1";
    param[@"q"] = result;
    param[@"only"] = @"translate";

    AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
    session.requestSerializer.stringEncoding = NSUTF8StringEncoding;
    [session GET:youdaoURL parameters:param progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"成功");
        NSLog(@"responseObject = %@", responseObject);
        NSDictionary *translationDict = (NSDictionary *)responseObject;
        if ([translationDict isKindOfClass:[NSDictionary class]]) {
            NSString *voiceString = [[translationDict objectForKey:@"translation"] firstObject];
            NSLog(@"voiceString = %@", voiceString);
            self.translationLabel.text = voiceString;
            AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:voiceString];
            
            //所有发音类型
            //        NSLog(@"%@",[AVSpeechSynthesisVoice speechVoices]);
            
            //美式发音
            AVSpeechSynthesisVoice *voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"en-US"];
            utterance.voice = voice;
            AVSpeechSynthesizer *synth = [[AVSpeechSynthesizer alloc]init];
            [synth speakUtterance:utterance];
        }

    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"失败");
    }];
    
}

- (void)speechRecognitionTaskFinishedReadingAudio:(SFSpeechRecognitionTask *)task
{
    NSLog(@"%s", __FUNCTION__);

}

- (void)speechRecognitionTaskWasCancelled:(SFSpeechRecognitionTask *)task
{
    NSLog(@"%s", __FUNCTION__);

}

- (void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didFinishSuccessfully:(BOOL)successfully
{
    NSLog(@"%s", __FUNCTION__);

}
@end
