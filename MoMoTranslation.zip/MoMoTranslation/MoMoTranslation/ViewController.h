//
//  ViewController.h
//  MoMoTranslation
//
//  Created by Jim on 2016/12/20.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

